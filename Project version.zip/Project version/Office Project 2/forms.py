from flask_wtf import FlaskForm
from wtforms import SelectField,IntegerField, PasswordField, SubmitField, BooleanField, StringField
from wtforms.validators import DataRequired, Email,Length


class LoginForm(FlaskForm):
    BU = SelectField('BU', choices=[("ATI","ATI"),("ANA","ANA"),("ASC","ASC"),("KOG","KOG")])
    Environment = SelectField('Environment', choices=[("QA", "QA"),('DEV',"DEV"),("STG","STG")])
    Database = SelectField('Database', choices=[("AZSQL", "AZSQL"), ("SQLRP", "SQLRP"),("Other","Other")])
    if Database=='Other':
        Database = StringField("Enter the Database name",validators=[DataRequired])
    else:
        final_avs=SelectField('Select the Avalability Set',choices=[('a','s')])
    Sequence_number=IntegerField('Sequence Number',validators=[DataRequired])
    submit = SubmitField('Submit')

class  SecondForm(FlaskForm):
    Resource_grp_name=StringField('Resource Group Name',validators=[DataRequired])
    submit1=SubmitField('Submit')

class ThirdForm(FlaskForm):
    Avalability_set=SelectField('Create New Avalability Set',choices=[('Yes','Yes'),('No','No')])
    print(Avalability_set)
    if Avalability_set=='Yes':
        new_avs = StringField("Enter name of the New Availability set",validators=[DataRequired])
    else:
        final_avs=SelectField('Select the Avalability Set',choices=[('a','s')])
    submit2=SubmitField('Submit')