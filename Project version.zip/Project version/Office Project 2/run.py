from flask import Flask, render_template, url_for, flash, redirect
from forms import LoginForm,SecondForm,ThirdForm
import cgi
import os
import subprocess
from azure.cli.core import get_default_cli
app=Flask(__name__)

app.config['SECRET_KEY']='df913ac40f997e9f643927a32bee2a56'

@app.route('/')
def main():
    form=LoginForm()
    form1=SecondForm()
    form2=ThirdForm()
    return render_template('Win_creation.html',form=form,form1=form1,form2=form2)

@app.route('/read', methods=['GET', 'POST'])
def read():
    form = LoginForm()
    form1=SecondForm()
    form2=ThirdForm()
    value1=form.BU.data
    value2=form.Environment.data
    value3=form.Database.data
    value4=form.Sequence_number.data
    value4=str(value4)
    str1=(value1,value2,value3,value4)
    vm_name="-"
    vm_name=vm_name.join(str1)
#    print(vm_name)
    #  Resource_grp_name=get_default_cli().invoke(['group', 'list', '--output', 'table'])==0
    return render_template('Win_creation.html', form=form ,vm_name= vm_name,form1=form1,form2=form2)

@app.route('/read1', methods=['GET', 'POST'])
def read1():
    form=LoginForm()
    form1=SecondForm()
    form2=ThirdForm()
    Resource_grp_list = get_default_cli().invoke(['group', 'list', '--output', 'table']) == 0
    Resource_grp_name=form1.Resource_grp_name.data
    return render_template('Win_creation.html', form=form ,Resource_grp_name=Resource_grp_name,
                           Resource_grp_list=Resource_grp_list,form1=form1,form2=form2)

@app.route('/read2', methods=['GET','POST'])
def read2():
    form=LoginForm()
    form1=SecondForm()
    form2=ThirdForm()
    print(form1.Resource_grp_name)
    final_avs=""
    Resource_grp_list = get_default_cli().invoke(['vm', 'availability-set', 'list', '-g', str(form1.Resource_grp_name), '--output','table']) == 0
    #Resource_grp_name=form1.Resource_grp_name.data
    Avalability_set=form2.Avalability_set.data
    if form2.Avalability_set.data=='Yes':
        new_avs=form2.new_avs.data
        avs_cmd =get_default_cli().invoke(['vm', 'availability-set', 'create', '--name', str(new_avs), '--resource-group', str(form1.Resource_grp_name),
                   '--platform-fault-domain-count', '2', '--platform-update-domain-count', '2'])
        final_avs=new_avs
    else:
        final_avs=form2.final_avs.data
    return render_template('Win_creation.html', form=form , form2=form2,
                           Resource_grp_list=Resource_grp_list,form1=form1,final_avs=final_avs,Avalability_set=Avalability_set)

if __name__=='__main__':
    app.run(debug=True)