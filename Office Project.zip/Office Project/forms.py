from flask_wtf import FlaskForm
from wtforms import SelectField, PasswordField, SubmitField, BooleanField, StringField
from wtforms.validators import DataRequired, Email,Length


class LoginForm(FlaskForm):
    BU = SelectField('BU', choices=[("A",1),("B",2)])
    Database = SelectField('Database', choices=[("A", 1),('B',2)])
    Resource = SelectField('Resource', choices=[("A", 1), ("B", 2)])
    submit = SubmitField('Login')
