from flask import Flask, render_template, url_for, flash, redirect
from forms import LoginForm
import cgi
app=Flask(__name__)

app.config['SECRET_KEY']='df913ac40f997e9f643927a32bee2a56'

@app.route('/', methods=['GET', 'POST'])
def read():
    form = LoginForm()
    #if form.validate_on_submit():
    value1=form.BU.data
    value2=form.Database.data
    value3=form.Resource.data
    str=(value1,value2,value3)
    value=","
    value=value.join(str)
    print(value)
       # flash('You have been logged in!',value)
   #     return redirect(url_for('read'))
    return render_template('Win_creation.html', title='Login', form=form ,value= value)


@app.route("/main")
def main():
    return render_template("Win_creation.html")

if __name__=='__main__':
    app.run(debug=True)