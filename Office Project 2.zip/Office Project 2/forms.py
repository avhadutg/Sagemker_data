from flask_wtf import FlaskForm
from wtforms import SelectField,IntegerField, PasswordField, SubmitField, BooleanField, StringField
from wtforms.validators import DataRequired, Email,Length


class LoginForm(FlaskForm):
    BU = SelectField('BU', choices=[("ATI","ATI"),("ANA","ANA"),("ASC","ASC"),("KOG","KOG")])
    Environment = SelectField('Environment', choices=[("QA", "QA"),('DEV',"DEV"),("STG","STG")])
    Database = SelectField('Database', choices=[("AZSQL", "AZSQL"), ("SQLRP", "SQLRP"),("Other","Other")])
    Sequence_number=IntegerField('Sequence Number',validators=[DataRequired])
    submit = SubmitField('Submit')

class  SecondForm(FlaskForm):
    Resource_grp_name=StringField('Resource Group Name',validators=[DataRequired])
    submit1=SubmitField('Submit')